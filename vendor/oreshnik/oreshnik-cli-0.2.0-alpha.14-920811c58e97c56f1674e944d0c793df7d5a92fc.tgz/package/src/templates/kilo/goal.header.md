---
description: Oreshnik persistent Goal Runner with bounded gates
agent: code
---

<!-- ORESHNIK:LOCAL_CLI_RESOLVER BEGIN -->
# Oreshnik Local CLI Resolver

Do NOT install Oreshnik globally. Do NOT download or update packages during a Goal.

When a step instructs `oreshnik ...`, resolve the local CLI using this priority:

1. **Within Oreshnik repository** (current working directory is an Oreshnik source checkout):
   - Use `node dist/cli.js`
   - Example: `node dist/cli.js align --check --harness kilo --json`

2. **Oreshnik as local npm dependency** (node_modules/oreshnik exists):
   - Use `node_modules/.bin/oreshnik.cmd` (Windows) or `node_modules/.bin/oreshnik` (Unix)

3. **Oreshnik installed locally but not linked**:
   - Use `npx --no-install oreshnik`

Never rely on a global `oreshnik` command. Never run `npm install` or `npm update` during goal execution.

When the managed block below references `oreshnik`, substitute the resolved local CLI path.
<!-- ORESHNIK:LOCAL_CLI_RESOLVER END -->
