# Changelog

## [Unreleased]

## [0.3.0-alpha.6] - 2026-08-14

### Added

- Add provider-neutral AI/LLM telemetry with explicit operator, harness, model, reasoning, cognitive activity and execution-provider provenance.
- Add truthful usage and billing semantics that preserve unavailable/estimated/provider-reported distinctions instead of coercing unknown token or cost values to zero.
- Add efficiency attribution, unified telemetry reporting and an advisory optimizer that recommends but does not autonomously mutate execution routing.
- Validate the architecture with a real Trinity ChatGPT → Oreshnik → GitHub Actions canary, exact execution correlation, no Codex/Kilo fallback and no product regression.

### Compatibility

- Preserve Alpha5 execution-fabric, provider-parity, approval-lease, Render and governed-validation public behavior; AITEL is additive.

## [0.3.0-alpha.5.9] - 2026-08-08

### Fixed

- Rehydrate an exact preserved dispatch identity on a fresh ephemeral runner when the caller supplies the existing Assignment UID or alias and the operator, harness, session, Run and remote control-plane identity all match.
- Preserve the existing `--instance new` takeover contract, takeover fencing, cross-operator authorization, concurrent-takeover exclusion, remote-branch divergence protection and idempotent retry semantics.

## [0.3.0-alpha.5.8] - 2026-08-08

### Added

- Add a governed Render shadow/parity runner that compares structured evidence against a canonical local or GitHub Actions reference and keeps Render shadow-only until the configured sample threshold is reached with zero semantic discrepancies.
- Add CAS-governed amendments for pending, ready or blocked canonical Tasks so scope/version changes can update task-board, Goal and Task artifact atomically without manual projection edits.

### Fixed

- Bind Render One-Off workers to the exact installed Oreshnik CLI release instead of a stale Alpha5 package fallback.

## [0.3.0-alpha.4] - 2026-08-06

### Added

- Add the canonical `task terminalize` operation: a persisted, idempotent, resumable terminalization saga with durable phases (`terminalization_prepared`, `canonical_projection_persisted`, `integration_confirmed`, `control_projection_confirmed`, `resources_released`, `terminalization_verified`), correlation IDs, CAS-guarded master and control writes, and explicit non-success statuses (`terminalization_in_progress`, `terminalization_incomplete`, `terminalization_uncertain`, `terminalization_recovery_required`).
- Terminal verification re-reads `origin/master` and `origin/oreshnik/control` plus every canonical artifact (Task, task board, Run, Claim, handoff, session, zones, catalog) and fails closed on any contradiction before a terminal report can be produced.
- Extend `dispatch reconcile` to detect terminal-projection divergences (control released with Task claimed, Run released after durable integration, activeRun with released Claim, stale identity after takeover, missing terminal handoff, board/artifact divergence, stale control catalog head, premature resource release), report the missing phase, and resume unverified terminalization journals idempotently.

### Fixed

- Rematerialize governed worktrees during cross-machine `dispatch takeover` before transferring control-plane ownership, and recover interrupted Runs from their remote functional branch on ephemeral runners.
- Release semantics: releasing an Assignment or Claim no longer degrades a Run whose terminal outcome is `integrated` or `failed`; `released` now strictly means an operational reservation was freed. Added `failed` as a terminal Run outcome.

## [0.3.0-alpha.2] - 2026-07-15

### Added

- Enable WinForms visual alerts by default on Windows through an explicit canonical `notifications.localVisual` block, platform-aware defaults, and `oreshnik notify migrate-config` for existing repositories.
- Refactor the notification ledger to v2 with per-channel delivery state (audio attempted/delivered, visual attempted/shown, bounded retries, per-channel timestamps) and a safe v1 migration.
- Add an explicit harness-interruption registry API (`HarnessInterruptionService`) — not an automatic detector — that, when a supervisor or integrator reports an unexpected harness exit, preserves the Run, persists a recoverable diagnostic, and emits `unexpected_agent_stop` or `run_blocked` with Task, Run, operator, harness, and recommended action.
- Extend `oreshnik notify status --json` with platform, backend availability, PowerShell and WinForms probes, interactive-session detection, ledger path/version, last event/audio/visual delivery timestamps.

### Fixed

- Converge dispatch worklist, `dispatch explain`, dry-run, real dispatch, claims, runs, sessions, zones, resources, and locks onto the same authoritative projected state.
- Reproject stale dependency blockers automatically so canonical Tasks such as G08 become dispatchable as soon as their integrated predecessors satisfy the dependency graph.
- Persist dispatcher success only after remote control-plane confirmation and keep lifecycle reservations idempotent across retries and resumes.
- Enforce `approvalMode=self` as the default autonomous runtime policy while reserving `ready_for_manual_qa` and explicit approval receipts for Tasks that declare `approvalMode=manual`.
- Prevent `--version`, `-V`, and `--help` from starting updater, interactive workflow, or any other runtime mutation path.
- Record notification delivery per channel after attempting it, so an event whose visual channel was disabled or failed can still show its window later without replaying delivered audio.

## [0.3.0-alpha.1] - 2026-07-14

- Publish the verified portable CLI release after G03 Alpha 1 readiness.

## [0.2.0-alpha.16] - 2026-07-10

### Added

- Add canonical `oreshnik handoff create|show|list|validate|resume` operator transfer workflows.
- Add versioned `oreshnik-handoff/v1` Zod and JSON schemas, deterministic SHA-256 integrity, Markdown rendering, and typed Task/Run references.
- Capture Git/worktree divergence, public GitHub PR checks and reviews, structured deployments and blockers, stability classification, and exact resumption guidance.
- Distribute handoff schemas and operator documentation in the package.

### Security

- Redact secret-like values, database connection strings, tokens, and private-key blocks before persistence.
- Use bounded typed Git process execution and a linear-time private-key scanner.
- Prevent handoff paths from escaping the repository and keep resume non-mutating.

### Release

- Publish TGZ and SHA-256 through an idempotent GitHub Release flow before npm publication.
- Publish prerelease packages only under the npm `alpha` dist-tag; preserve `latest` and alpha.15 rollback artifacts.

## [0.2.0-alpha.15] - 2026-07-09

### Changed

- Normalize the operational package identity back to canonical `0.2.0-alpha.15` for REL-15 packaging and HeptaCore adoption.
- Treat the prior `0.2.0-alpha.15.1`, `0.2.0-alpha.15.2`, and `0.2.0-alpha.15.3` entries below as historical hotfix evidence for the alpha.15 line, not as independent operational release targets.

## [0.2.0-alpha.15.3] - 2026-07-07

Historical alpha.15 hotfix evidence.

### Fixed

- Configure Git author and committer identity in the Oreshnik Cloud GitHub Actions workflow so governed `mode=assign` control-plane commits can be created by `github-actions[bot]`.

## [0.2.0-alpha.15.2] - 2026-07-06

Historical alpha.15 hotfix evidence.

### Fixed

- Normalize dispatcher repository origin comparison so GitHub Actions checkouts without `.git` remain compatible with existing `oreshnik/control` states initialized from `.git` remotes.
- Accept legacy dispatcher `repository.id` values derived from literal origin URLs with `.git` while still failing closed for real repository or mother-branch mismatches.

## [0.2.0-alpha.15.1] - 2026-07-06

Historical alpha.15 hotfix evidence.

### Fixed

- Make `oreshnik dispatch peek` and `dispatch next --dry-run --json` fully read-only by bypassing remote dispatch lock acquisition while still resolving the contract from canonical control-plane and task-board state.
- Add integration coverage that verifies `peek` leaves `origin/oreshnik/control` unchanged and does not create `oreshnik-lock/*` tags in the remote repository.

## [0.2.0-alpha.15] - 2026-07-06

### Added

- Oreshnik Cloud manual workflow with `status`, `peek`, and governed `assign` modes, durable `result.json` / `result.md`, artifact upload, step summary, and optional PR commenting.
- Explicit `oreshnik dispatch peek` alias for read-only task inspection that reuses the existing dispatcher dry-run contract.
- Cloud governance documentation for the ChatGPT connector contract and the ADR that separates cloud governance from any future autonomous API agent mode.

## [0.2.0-alpha.14] - 2026-07-05

### Added

- Goal Runner target-safe con --task.
- Auto-align acotado a un solo intento de reparación.
- Adapter Kilo completo para instalación limpia con resolver local.
- Diagnóstico de linaje read-only en dispatch explain.
- Lifecycle block, unblock y resume con Run preservado.

### Fixed

- Dispatch nuevo permitido únicamente para Tasks ready sin blockState.
- Exclusión de pending y blocked legacy.
- Propagación completa de operator, harness, instance y session en resume.
- Reutilización de identidad resuelta después de --instance new.
- Instalación empaquetada del adapter sin dependencia de CLI global.

### Known deferred work

- Recuperación transaccional ante fallos parciales.
- Fault injection.
- Adoption automática de branches preexistentes.
- Rebind dinámico de rama madre.
- Provenance de adoption.
- Endurecimiento de dependencias.
- Goal amend/supersede.
- Certificación multi-harness y reconcile final.

Alpha.14 soporta el flujo ordinario:
Task ready → Goal/dispatch → Run/worktree → block/resume normal → gates → close/integrate.

No afirma soportar adopción automática de branches preexistentes ni recuperación
garantizada ante una caída exactamente entre mutaciones remotas.

## [0.2.0-alpha.13] - 2026-07-04

### Added

- Add the Lifecycle router for `GENESIS`, `ADOPTION`, `MANAGED`, and `MANAGED_INCOMPLETE`, including non-destructive intake, adoption, join, align, resume, and dispatch flows.
- Add non-blocking review governance with explicit `audit_only`, `advisory`, and `strict` review modes plus auditable owner self-approval metadata.
- Add reversible/compensatable/irreversible action contracts, checkpoint bundle auditing, deadlock prevention, and Notify-backed lifecycle completion signaling.

### Fixed

- Reconcile canonical catalog state so Notify is durably integrated and Lifecycle is dispatchable from the authoritative task board and task artifacts.
- Respect configured validation gate timeouts on already-contained integrations and isolate stale-review governance checks from unrelated preflight blockers.
- Harden dispatcher control-plane bootstrap when the remote `oreshnik/control` branch is legitimately absent during first initialization.

## [0.2.0-alpha.11] - 2026-06-30

### Fixed

- Honor configured `timeoutSeconds` in `oreshnik gate` when using the structured async gate runner.
- Match task gate entries written as executable commands, such as `npm run test`, to configured gate names during evidence validation.
- Serialize local execution identity state updates and write them atomically, preventing concurrent dispatchers from corrupting `agent-instances.json` or `execution-sessions.json`.

## [0.2.0-alpha.10] - 2026-06-30

### Fixed

- Publish runtime projection commits with an explicit `HEAD:refs/heads/<mother>` refspec so already-contained integrations advance the remote mother branch to the runtime state commit instead of leaving it at the functional commit.

## [0.2.0-alpha.9] - 2026-06-30

### Added

- Add additive execution-identity modeling for `operator`, `harnessId`, `agentInstanceUid` / alias, and `sessionId` across dispatcher manifests, claims, runs, zones, and worktree ownership.
- Add `oreshnik align` for context diagnosis, Kilo adapter installation/update, and safe recovery evidence for terminal owned worktrees.
- Add `oreshnik goal` as the canonical execution entry point that aligns, resolves context, then resumes or dispatches by exact instance.
- Add the canonical Kilo adapter template at `.kilo/commands/goal.md`, keep `.kilo/command/goal.md` as a managed compatibility mirror, and install both from `init` / `align --apply`.
- Add the missing `scripts/oreshnik/close-sprint.mjs` wrapper so `AGENTS.md` and the native `oreshnik close` flow are executable together again.

### Fixed

- Refresh dispatcher control-plane state with `fetch --no-tags` so synthetic and real close-resume flows do not fail on safe local checkpoint-tag divergence.
- Preserve idempotent dispatcher release/reconcile flows after simulated partial close recovery rewrites a local checkpoint tag.
- Retry dispatcher control-plane fetches and remote tag mutations under local bare-remote contention on Windows.
- Allow an explicit audited override for `dispatch supersede` when the caller intentionally supersedes the only active run for a task after preserving local state.
- Serialize Vitest file execution to keep bare-remote Git integration fixtures deterministic on Git for Windows.
