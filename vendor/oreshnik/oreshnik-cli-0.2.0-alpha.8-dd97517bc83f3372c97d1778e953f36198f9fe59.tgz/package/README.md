# Oreshnik

**Git-native sprint management system — CLI-first, dashboard-optional.**

[![npm version](https://img.shields.io/npm/v/oreshnik)](https://www.npmjs.com/package/oreshnik)
[![License: MIT](https://img.shields.io/badge/License-MIT-purple.svg)](LICENSE)
[![Node.js >= 20](https://img.shields.io/badge/node-%3E%3D20-green.svg)](https://nodejs.org)

## One command. Zero config.

```bash
npx oreshnik init
```

Detects your stack (Next.js, Vite, Astro, monorepo, TypeScript, Node), creates zone-map, task-board, vault, and operator config.

```bash
npx oreshnik
```

Interactive start — detects your operator from `git config user.name`, shows your tasks, validates dependencies, and optionally resolves blockers.

---

## Commands

### Core Workflow

| Command | Description |
|---|---|
| `oreshnik` | Interactive start: operator detection, sprint selection, blocker resolution |
| `oreshnik init` | Initialize Oreshnik in current git repo (`--force`, `--template`, `--interactive`) |
| `oreshnik preflight` | 11-step validation: sync, vault, zone-check, locks, canonical, tasks, secrets, build |
| `oreshnik close` | Close sprint: validates evidence, runs gates, creates MADRE branch |
| `oreshnik status` | Show project state, branch, checkpoints |

### Multi-Project

| Command | Description |
|---|---|
| `oreshnik portfolio` | Inspect multi-project portfolio configuration |
| `oreshnik dashboard` | Multi-project dashboard with operator breakdown and lock status (`--detail`, `--json`, `--markdown`) |
| `oreshnik ingest` | Ingest meeting notes markdown into classified backlog |
| `oreshnik inject` | Inject classified tasks into project task-boards |
| `oreshnik bootstrap` | Initialize Oreshnik structure across portfolio projects |

### Validation

| Command | Description |
|---|---|
| `oreshnik zone-check` | Validate zone-map compliance across projects |
| `oreshnik evidence` | Validate task evidence before sprint closure (`--check`) |
| `oreshnik gate` | Run validation suite (typecheck, build, tests) |
| `oreshnik audit` | Cross-project audit: git history, checkpoints, secrets |

### Locking & Recovery

| Command | Description |
|---|---|
| `oreshnik lock` | Distributed zone locks via git tags (`--acquire`, `--release`, `--status`) |
| `oreshnik checkpoint` | Create manual checkpoint tag |
| `oreshnik rollback` | Restore to previous checkpoint |
| `oreshnik timeline` | Show checkpoint and sprint timeline |
| `oreshnik integrate` | Merge sprint into a target branch with zone checks |

### `oreshnik reconcile`
Validate and regenerate canonical derived documents from the task board.
- `--check` — Report misalignments without modifying files (exit 1 if issues found)
- `--write` — Regenerate `<!-- ORESHNIK:GENERATED -->` sections, preserving manual content
- `--json` — Machine-readable output
- `--sprint <id>` — Filter by sprint
- `--operator <name>` — Filter by operator

---

## Architecture

Oreshnik is **Git-native**. All state lives in files tracked by git:

| Artifact | Location |
|---|---|
| Task board | `var/oreshnik/task-board.json` |
| Zone map | `docs/07_handoffs/zone-map.json` |
| Portfolio | `.oreshnik.portfolio.json` |
| Config | `.oreshnik.json` |
| Locks | `refs/tags/oreshnik-lock/*` |
| Checkpoints | `refs/tags/oreshnik/*` |
| Vault | `docs/obsidian-vault/` |

**No database. No external service. No cloud dependency.** The source of truth is the git repo.

## Concepts

### Zones
Filesystem paths controlled by operators. Zone maps define who can modify which files during which sprints. Violations are detected by `zone-check` and surfaced in preflight.

### Locks
Atomic distributed locks via git tags. When an operator starts a sprint on a zone, they acquire a lock. Other operators see `[LOCK]` warnings in preflight. Locks auto-expire (TTL, default 1 hour).

### Task Board
A JSON file tracking all tasks: ID, title, owner, status (ready/active/blocked/done/pending), dependencies, acceptance criteria, and history.

### Canonical Docs
Derived markdown documents regenerated from the task board on each close. Includes central dashboard, operator status files, and status board. Preflight validates they match the task board.

### Evidence Gates
Tasks marked `done` must have verifiable evidence: file changes, typecheck success, test results. Preflight and close validate this.

## Operators

Multiple operators collaborate on the same repo via git branches:

```
MADRE/v5-s-oreshnik-07-... → mother branch (source of truth)
Architect/s-oreshnik-07-... → architect's work branch
Jean/s-hc-prod-02-...       → Jean's work branch
Manuel/s-hc-prod-03-...     → Manuel's work branch
```

Oreshnik detects divergence, backs up local work, and aligns on each session start.

## Install

```bash
npm install -g oreshnik
# or
npx oreshnik init
```

**Requirements**: Node.js >= 20, git >= 2.30

## License

MIT © 2026 Oreshnik Team
