# Oreshnik

**Git-native sprint management system, CLI-first and multi-operator.**

[![npm version](https://img.shields.io/npm/v/oreshnik)](https://www.npmjs.com/package/oreshnik)
[![License: MIT](https://img.shields.io/badge/License-MIT-purple.svg)](LICENSE)
[![Node.js >= 20](https://img.shields.io/badge/node-%3E%3D20-green.svg)](https://nodejs.org)

## Quick Start

```bash
npx oreshnik init
```

Detects your stack, creates `.oreshnik.json`, `task-board.json`, `zone-map.json`, the vault scaffold, and the canonical Kilo adapter template.

```bash
npx oreshnik goal --harness kilo
```

Runs the canonical execution flow: `align --check`, execution-context resolution, then exact resume or fresh dispatch for the current instance.

```bash
npx oreshnik
```

Keeps the legacy interactive start flow for single-console usage.

## Core Commands

Operator transfer is documented in [Canonical operator handoff](docs/OPERATOR_HANDOFF.md).

| Command | Description |
|---|---|
| `oreshnik goal` | Canonical run entry point: align, resolve context, resume or dispatch (`--harness`, `--instance`, `--json`) |
| `oreshnik align` | Diagnose or repair operator, harness, instance, session, adapter, and terminal ownership state (`--check`, `--apply`, `--force`) |
| `oreshnik dispatch` | Atomic control-plane dispatcher for multi-console assignment, resume, release, reconcile, and supersede |
| `oreshnik init` | Initialize Oreshnik in the current repository |
| `oreshnik preflight` | Run validation before starting work |
| `oreshnik close` | Close a sprint after evidence and gate validation |
| `oreshnik reconcile` | Check or regenerate canonical derived documentation |
| `oreshnik status` | Show project and runtime state |

## Execution Context

Oreshnik separates human identity from execution substrate:

- `operator`: registered human
- `harnessId`: console substrate such as `kilo`, `codex`, or `shell`
- `agentInstanceAlias`: deterministic instance alias such as `manuel-kilo1`
- `sessionId`: active session for that exact instance

`goal`, `align`, and `dispatch` share the same resolver, so a resumed run always belongs to the exact instance that claimed it.

## Goal

`oreshnik goal`:

- runs an internal alignment check first
- resolves `operator`, `harness`, `instance`, and `session`
- resumes the exact active run for the instance before asking for a new task
- returns structured JSON with task metadata, recommendation, and actual execution context

## Align

`oreshnik align`:

- `--check` diagnoses missing selection, ambiguous instances, stale Kilo adapters, or terminal ownership without mutating local state
- `--apply` creates or recovers the local instance/session, installs or updates `.kilo/commands/goal.md`, maintains the legacy `.kilo/command/goal.md` mirror, and preserves terminal worktree evidence before detaching stale ownership
- `--force` backs up and replaces an unmanaged custom Kilo goal file when safe reconciliation is not possible

## Kilo Adapter

For Kilo, `init` and `align --apply` install a canonical adapter at `.kilo/commands/goal.md` and keep `.kilo/command/goal.md` in sync for legacy consumers.

- The template is versioned.
- The same file serves every operator.
- It never hardcodes human IDs.
- It delegates to `oreshnik goal --harness kilo --json`.

## Close Workflow

Repository automation can call either:

- `oreshnik close --sprint <id> --operator <name> --desc "..."`
- `node scripts/oreshnik/close-sprint.mjs --sprint <id> --operator <name> --desc "..."`

The wrapper exists for `AGENTS.md` and other repo workflows, but it delegates to the native `oreshnik close` engine.

## Architecture

Oreshnik is Git-native. State lives in repository files and refs:

| Artifact | Location |
|---|---|
| Task board | `var/oreshnik/task-board.json` |
| Zone map | `docs/07_handoffs/zone-map.json` |
| Config | `.oreshnik.json` |
| Portfolio | `.oreshnik.portfolio.json` |
| Dispatch locks | `refs/tags/oreshnik-lock/*` |
| Checkpoints | `refs/tags/oreshnik/*` |
| Vault | `docs/obsidian-vault/` |

No database. No external coordinator. Git remains the source of truth.

## Install

```bash
npm install -g oreshnik
```

or run directly:

```bash
npx oreshnik init
```

**Requirements**: Node.js >= 20, git >= 2.30

## License

MIT © 2026 Oreshnik Team
