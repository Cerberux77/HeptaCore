# Canonical operator handoff

`oreshnik handoff` captures a versioned, integrity-protected checkpoint without committing, pushing, releasing a claim, or changing lifecycle state.

## Commands

```text
oreshnik handoff create --task <task> --run <run> --operator <operator> --reason <reason>
oreshnik handoff show --task <task> [--id <handoff>]
oreshnik handoff list [--task <task>]
oreshnik handoff validate --path <json>
oreshnik handoff resume --task <task> [--id <handoff>]
```

`create` discovers Task, Run, claim, Git, worktree, upstream, divergence, local changes, stash, conflicts, and public GitHub PR metadata. Functional state, deployments, and structured blockers can be declared explicitly. Declared values are redacted before persistence.

JSON is stored under `var/oreshnik/handoffs/<task>/`; its Markdown rendering is stored under `docs/oreshnik/handoffs/<task>/`. Valid canonical Task and Run artifacts receive a typed reference containing the schema, paths, classification, and SHA-256 digest.

## Safety

- Secret-like values and database connection strings become `[REDACTED]`.
- Output paths must remain inside the repository.
- `resume` validates integrity, branch, HEAD, worktree existence, supersession, and prior claim state. It never steals or renews a claim.
- Git commands use typed argument arrays with `spawnSync` and `shell: false`.
- GitHub/provider failures degrade to explicit unavailable metadata instead of blocking local capture.

## Stability

- `STABLE_COMPLETE`: clean repository with no declared partial work or blockers.
- `STABLE_PARTIAL`: safe checkpoint with uncommitted/partial work or pending tests.
- `UNSTABLE_RECOVERABLE`: internal blocking failure, conflict, or failed blocking deployment.
- `BLOCKED_EXTERNAL`: blocking credential, provider, or human-approval dependency.

The runtime schema is enforced by Zod in `src/core/handoff.service.ts`; the distributable JSON Schema is `schemas/oreshnik-handoff-v1.schema.json`.
