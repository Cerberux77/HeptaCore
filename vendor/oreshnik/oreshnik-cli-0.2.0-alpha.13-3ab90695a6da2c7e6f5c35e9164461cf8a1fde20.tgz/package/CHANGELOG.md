# Changelog

## [0.2.0-alpha.13] - 2026-07-04

### Added

- Add the Lifecycle router for `GENESIS`, `ADOPTION`, `MANAGED`, and `MANAGED_INCOMPLETE`, including non-destructive intake, adoption, join, align, resume, and dispatch flows.
- Add non-blocking review governance with explicit `audit_only`, `advisory`, and `strict` review modes plus auditable owner self-approval metadata.
- Add reversible/compensatable/irreversible action contracts, checkpoint bundle auditing, deadlock prevention, and Notify-backed lifecycle completion signaling.

### Fixed

- Reconcile canonical catalog state so Notify is durably integrated and Lifecycle is dispatchable from the authoritative task board and task artifacts.
- Respect configured validation gate timeouts on already-contained integrations and isolate stale-review governance checks from unrelated preflight blockers.
- Harden dispatcher control-plane bootstrap when the remote `oreshnik/control` branch is legitimately absent during first initialization.

## [0.2.0-alpha.11] - 2026-06-30

### Fixed

- Honor configured `timeoutSeconds` in `oreshnik gate` when using the structured async gate runner.
- Match task gate entries written as executable commands, such as `npm run test`, to configured gate names during evidence validation.
- Serialize local execution identity state updates and write them atomically, preventing concurrent dispatchers from corrupting `agent-instances.json` or `execution-sessions.json`.

## [0.2.0-alpha.10] - 2026-06-30

### Fixed

- Publish runtime projection commits with an explicit `HEAD:refs/heads/<mother>` refspec so already-contained integrations advance the remote mother branch to the runtime state commit instead of leaving it at the functional commit.

## [0.2.0-alpha.9] - 2026-06-30

### Added

- Add additive execution-identity modeling for `operator`, `harnessId`, `agentInstanceUid` / alias, and `sessionId` across dispatcher manifests, claims, runs, zones, and worktree ownership.
- Add `oreshnik align` for context diagnosis, Kilo adapter installation/update, and safe recovery evidence for terminal owned worktrees.
- Add `oreshnik goal` as the canonical execution entry point that aligns, resolves context, then resumes or dispatches by exact instance.
- Add the canonical Kilo adapter template at `.kilo/commands/goal.md`, keep `.kilo/command/goal.md` as a managed compatibility mirror, and install both from `init` / `align --apply`.
- Add the missing `scripts/oreshnik/close-sprint.mjs` wrapper so `AGENTS.md` and the native `oreshnik close` flow are executable together again.

### Fixed

- Refresh dispatcher control-plane state with `fetch --no-tags` so synthetic and real close-resume flows do not fail on safe local checkpoint-tag divergence.
- Preserve idempotent dispatcher release/reconcile flows after simulated partial close recovery rewrites a local checkpoint tag.
- Retry dispatcher control-plane fetches and remote tag mutations under local bare-remote contention on Windows.
- Allow an explicit audited override for `dispatch supersede` when the caller intentionally supersedes the only active run for a task after preserving local state.
- Serialize Vitest file execution to keep bare-remote Git integration fixtures deterministic on Git for Windows.

## [0.2.0-alpha.7] - 2026-06-29

### Fixed

- Fall back to the already-synced local tracking branch when a remote branch confirmation query fails transiently during close resume.
- Stabilize repeated `close` runs after local checkpoint-tag rewrites in autonomous dispatcher-managed flows.
- Fall back to already-fetched tracking refs when dispatcher control-plane and assignment-branch inspections hit transient `ls-remote` failures under concurrent operators.

## [0.2.0-alpha.6] - 2026-06-29

### Fixed

- Sync only integration lock tags before opening a train, avoiding unrelated checkpoint tag conflicts during autonomous close/resume flows.
- Treat repositories with no remote lock tags yet as a valid clean state for train acquisition.

## [0.2.0-alpha.5] - 2026-06-29

### Fixed

- Allow active operators to execute `oreshnik integrate` for their already-queued deliveries instead of requiring a project owner session.
- Keep autonomous dispatcher-managed flows consistent from claim through close and integrate under the same operator identity.

## [0.2.0-alpha.4] - 2026-06-29

### Fixed

- Allow `oreshnik close` to fast-forward stale remote child and mother branches after the canonical close commit is created.
- Cover dispatcher-managed `close` publication when the remote child still points to the pre-close task commit.

## [0.2.0-alpha.3] - 2026-06-29

### Fixed

- Allow `oreshnik close` on dispatcher-managed child branches using `dispatch/<operator>/...`.
- Harden the dispatcher control-plane lock acquisition on release, supersede and reconcile under short-lived contention.

## [0.2.0-alpha.2] - 2026-06-29

### Fixed

- Allow active operators to receive dispatcher assignments for tasks owned by an active supervisory project owner.
- Read the published operator registry from the mother branch when scoring dispatcher eligibility, keeping dry-run and real claims aligned.

## [0.2.0-alpha.1] - 2026-06-29

### Fixed

- Wait for gate child processes to terminate on the real terminal event and persist structured gate results for evidence projection.
- Resume partial `close` executions idempotently, reusing the existing close commit and reconciling stale local tags safely.

## [0.2.0-alpha.0] - 2026-06-21
### Added
- `oreshnik reconcile --check` and `oreshnik reconcile --write` commands
- ORESHNIK:GENERATED markers for safe doc regeneration
- Reconcile check integrated into `oreshnik close` gate
- Windows spawn compatibility fix (shell: true)
- `cancelled` task status support

## [0.1.0-alpha] — 2026-06-13

### S-ORESHNIK-07: Close fix + Tests
- Close command no longer fails when no files to commit
- 5 checkpoint/timeline unit tests added (81 total tests, 10 test files)
- TaskHistoryEntry schema leniency: operator optional, supports from/to for reassignments

### S-ORESHNIK-06: Dashboard Operators & Locks
- Per-operator task breakdown (ready/active/done/blocked/pending)
- Active lock display per project from LockService
- `--detail` flag for per-task listing with dependencies
- Task status legend visible in dashboard output

### S-ORESHNIK-05: HeptaCore Validation
- Holistic multi-project start command with context detection
- Sprint dependency validation: detects [BLOCKED] sprints, offers blocker resolution
- Oreshnik installed as dependency in HeptaCore
- 11 npm scripts migrated to CLI wrappers
- Canonical docs (central, status board, operator state) created for both repos

### S-ORESHNIK-04: Integration Pipeline
- Conflict prediction and smart JSON merge
- Validation gates integration

### S-ORESHNIK-03: Init Command
- Stack-aware templates (nextjs, vite, astro, monorepo, fullstack, typescript, node)
- Auto-detection of project name, operator, and stack
- `--interactive` guided setup mode
- Stack-specific zone maps and validation gates

### S-ORESHNIK-02: Distributed Locks
- Zone locks via atomic git tags (`oreshnik-lock/*`)
- TTL-based auto-expiration (default 3600s)
- Lock check integrated into preflight step 4
- `oreshnik lock --acquire|--release|--status`

### S-ORESHNIK-01: Core Engine
- Git-native sprint management engine
- Result types, Zod schemas, CLI with Commander
- Portfolio service, injection service, ingestion service
- Evidence gates, canonical alignment, vault guard
- Zone engine, audit, rollback, timeline, checkpoints

### MT-01 to MT-10: Multi-Tenant
- Portfolio management across 6 projects (Oreshnik, HeptaCore, TurpialSound, TurpialMarket, DropSocial, SMSMantis)
- Meeting notes ingestion → classification → task injection
- Bootstrap, dashboard, zone-check, audit, secret scan
- HeptaCore integration with task distribution (Jean, Manuel, Architect)

### Foundation
- TypeScript CLI with tsup build
- Vitest test suite
- `npm run typecheck`, `npm run build`, `npm run test`
- CRLF/LF consistency, BOM handling
- Shell:true for Windows .cmd compatibility
