---
type: master-dashboard
project: "{{projectName}}"
last_updated: "{{timestamp}}"
---

# {{projectName}} — Dashboard Canonico

> Fuente operativa: `var/oreshnik/task-board.json`

## Estado Actual

| Campo | Valor |
|---|---|
| Task board | {{taskBoardStatus}} |
| Rama madre | {{motherBranch}} |

## Tareas

| Sprint | Estado | Owner | Scope |
|---|---|---|---|
| Ninguna | - | - | - |

## Reglas Activas

- No credenciales en git.
- No modificar archivos en zona forbidden.
- Ejecutar `oreshnik preflight` antes de trabajar.
- Cerrar sprints con `oreshnik close`.
